package underscore

//go:generate go run download.go --url https://underscorejs.org/underscore-min.js --output underscore-min.js
//go:generate go run download.go --url https://raw.githubusercontent.com/jashkenas/underscore/master/LICENSE --output LICENSE.underscorejs
