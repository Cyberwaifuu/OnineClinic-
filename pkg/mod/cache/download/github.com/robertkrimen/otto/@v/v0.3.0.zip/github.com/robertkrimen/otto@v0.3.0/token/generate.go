package token

//go:generate go run ../tools/gen-tokens -output token_const.go
