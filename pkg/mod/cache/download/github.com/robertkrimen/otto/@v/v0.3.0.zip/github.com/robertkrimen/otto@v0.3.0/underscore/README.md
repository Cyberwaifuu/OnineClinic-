# underscore

[![Reference](https://pkg.go.dev/badge/github.com/robertkrimen/otto/underscore.svg)](https://pkg.go.dev/github.com/robertkrimen/otto/underscore) [![License](https://img.shields.io/badge/MIT-blue.svg)](https://opensource.org/licenses/MIT)

To update the version of underscore run:

```shell
go generate
```
