package otto

import "golang.org/x/text/language"

var defaultLanguage = language.MustParse("en-US")
