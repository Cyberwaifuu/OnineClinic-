package gtranslate

// func init() {
// 	p, err := freeproxy.SetRandomProxyOnEnvVariable(freeproxy.Filter{
// 		OnlyHTTPS:      true,
// 		MaxLastChecked: time.Minute,
// 	})
// 	if err != nil {
// 		panic(err)
// 	}
// 	fmt.Printf("Setted %s:%s as proxy\n", p.IP, p.Port)
// }
